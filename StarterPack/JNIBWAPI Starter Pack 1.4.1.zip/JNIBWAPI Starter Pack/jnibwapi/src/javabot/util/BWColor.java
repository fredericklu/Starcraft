package javabot.util;

public class BWColor 
{
	public static final int RED = 111;
	public static final int BLUE = 165;
	public static final int TEAL = 159;
	public static final int PURPLE = 164;
	public static final int ORANGE = 179;
	public static final int BROWN = 19;
	public static final int WHITE = 255;
	public static final int YELLOW = 135;
	public static final int GREEN = 117;
	public static final int CYAN = 128;
	public static final int BLACK = 0;
	public static final int GREY = 74;
}
